<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function index()
	{
		$config = [
			'upload_path'=>'./uploads/',
			'allowed_types'=>'jpg|png',
			'max_size' => '400',
			'overwrite' => FALSE
			];

		$this->load->library('upload', $config);

		$this->form_validation->set_rules('name', 'Student Name', 'trim|required|strip_tags[name]');
		$this->form_validation->set_rules('email', 'E-mail', 'trim|required|valid_email|strip_tags[email]');
		$this->form_validation->set_rules('address', 'Address', 'trim|required|strip_tags[address]');
		$this->form_validation->set_rules('registration_id', 'Student ID', 'trim|required|numeric|strip_tags[registration_id]');
		$this->form_validation->set_rules('department', 'Department', 'trim|required|strip_tags[department]');
		$this->form_validation->set_rules('course_joined', 'Course Joined', 'trim|required|strip_tags[course_joined]');


		if (empty($_FILES['userfile']['name'])) 
		{
		 	$this->form_validation->set_rules('userfile', 'Profile picture', 'required|strip_tags[userfile]'); 
		}

		$view = array();
		if($this->form_validation->run() == TRUE)
		{
		    if(!$this->upload->do_upload('userfile'))
		    {
		        $view['upload_errors'] = $this->upload->display_errors();
		    }
		}
		else
		{
		    $view['form_error'] = validation_errors();
		}

		if(array_key_exists('upload_errors', $view) || array_key_exists('form_error', $view))
		{
			$this->load->view('registration',$view);
		}
		else
		{
		    $this->load->model('student_model');

			if($this->student_model->add_student())
			{
				$this->session->set_flashdata('success', 'Student added successfully');
				redirect('all_students');
			}
			else
			{
				print $this->db->error();
			}
		}
	}

	public function all_students()
	{
		$this->load->model('student_model');
		$view['students'] = $this->student_model->get_students();
		$this->load->view('all_students', $view);
	}

	public function add_marks()
	{
		$id = $this->uri->segment(2);
		$this->form_validation->set_rules('tamil', 'Tamil', 'trim|required|strip_tags[tamil]');
		$this->form_validation->set_rules('english', 'English', 'trim|required|strip_tags[english]');
		$this->form_validation->set_rules('maths', 'Maths', 'trim|required|strip_tags[maths]');
		$this->form_validation->set_rules('elective1', 'Elective1', 'trim|required|strip_tags[elective1]');
		$this->form_validation->set_rules('elective2', 'Elective2', 'trim|required|strip_tags[elective2]');
		$this->form_validation->set_rules('major', 'Major Paper', 'trim|required|strip_tags[major]');

		$view = array();
		if($this->form_validation->run() == TRUE)
		{
			$this->load->model('student_model');

			if($this->student_model->add_marks($id))
			{
				$this->session->set_flashdata('success', 'Student marks added successfully');
				redirect('all_students');
			}
			else
			{
				print $this->db->error();
			}
		}
		else
		{
		    $view['form_error'] = validation_errors();
		    $this->load->view('add_marks',$view);
		}

	}

	public function students_details(){
		$this->load->view('students_details');
	}

	public function ajax_list()
    {
    $this->load->model('student_model');
     // POST data
     $postData = $this->input->post();

     // Get data
     $data = $this->student_model->getStudents($postData);

     echo json_encode($data);
    }

}
