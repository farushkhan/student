<?php 

/**
 * 
 */
class Student_model extends CI_Model
{
	 
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
 
	public function add_student()
	{
		$data = $this->upload->data();
    	$image_path = base_url("uploads/".$data['raw_name'].$data['file_ext']);

    	$data = array(
    		'name'	=> $this->input->post('name'),
    		'email'		=> $this->input->post('email'),
    		'address'	=> $this->input->post('address'),
    		'registration_id' 	=> $this->input->post('registration_id'),
    		'department' 	=> $this->input->post('department'),
    		'course_joined' 	=> date('Y-m-d',strtotime($this->input->post('course_joined'))),
    		'profile_image' => $image_path
    	);

    	$insert_student = $this->db->insert('students', $data);
    	return $insert_student;
	}

    public function get_students()
    {
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get('students');
        return $query->result();
    }

    public function get_student_details($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('students');
        return $query->row();
    }

    public function add_marks($id)
    {
        $data = array(
            'student_id' => $id,
            'tamil'  => $this->input->post('tamil'),
            'english'     => $this->input->post('english'),
            'maths'   => $this->input->post('maths'),
            'elective1'    => $this->input->post('elective1'),
            'elective2'    => $this->input->post('elective2'),
            'major'     => $this->input->post('major'),
        );

        $insert_marks = $this->db->insert('student_marks', $data);
        return $insert_marks;
    }

    public function getStudents($postData=null){
        $response = array();

         ## Read value
         $draw = $postData['draw'];
         $start = $postData['start'];
         $rowperpage = $postData['length']; // Rows display per page
         $columnIndex = $postData['order'][0]['column']; // Column index
         $columnName = $postData['columns'][$columnIndex]['data']; // Column name
         $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
         $searchValue = $postData['search']['value']; // Search value

         ## Search 
         $searchQuery = "";
         if($searchValue != ''){
            $searchQuery = " (name like '%".$searchValue."%' or email like '%".$searchValue."%' ) ";
         }

         ## Total number of records without filtering
         $this->db->select('count(*) as allcount');
         $records = $this->db->get('students')->result();
         $totalRecords = $records[0]->allcount;

         ## Total number of record with filtering
         $this->db->select('count(*) as allcount');
         if($searchQuery != '')
            $this->db->where($searchQuery);
         $records = $this->db->get('students')->result();
         $totalRecordwithFilter = $records[0]->allcount;

         ## Fetch records
         $this->db->select("* , (`tamil` + `english` + `maths` + `elective1` + `elective2` + `major`) AS total");
         $this->db->join('student_marks as marks', 'marks.student_id =  students.id', 'LEFT');
         if($searchQuery != '')
            $this->db->where($searchQuery);
         $this->db->order_by($columnName, $columnSortOrder);
         $this->db->limit($rowperpage, $start);
         $records = $this->db->get('students')->result();

         $data = array();

         foreach($records as $record ){
            $avg = 0;
            if($record->total != 0){
                $avg = $record->total/6;
            }
            
            $data[] = array( 
               "name"=>$record->name,
               "email"=>$record->email,
               "department"=>$record->department,
               "registration_id"=>$record->registration_id,
               "course_joined"=>$record->course_joined,
               "tamil"=>$record->tamil,
               "english"=>$record->english,
               "maths"=>$record->maths,
               "elective1"=>$record->elective1,
               "elective2"=>$record->elective2,
               "major"=>$record->major,
               "total"=>$record->total,
               "avg"=> $avg,
            ); 
         }

         ## Response
         $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordwithFilter,
            "aaData" => $data
         );

         return $response; 
    }

}