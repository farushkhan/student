
<!DOCTYPE html>
<html>
  <head>
     <title>Student Details</title>

  <br>
  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <!-- Font-awesome css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/all.css'); ?>">

    <!-- My css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/style.css'); ?>">
     <!-- Datatable CSS -->
    <link href="<?php echo base_url('assets/datatables/css/jquery.dataTables.min.css')?>" rel="stylesheet">

  </head>
  <body>
     <a class="btn btn-primary" href="<?= base_url('all_students'); ?>">Add Marks</a>
      <a class="btn btn-primary" style="float: right;" href="<?= base_url(); ?>">Registration</a>
     <!-- Table -->
     <table id='studentTable' class='display dataTable'>

       <thead>
         <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Division</th>
            <th>Registration ID</th>
            <th>Course Joined</th>
            <th>Tamil</th>
            <th>English</th>
            <th>Maths</th>
            <th>Elective1</th>
            <th>Elective2</th>
            <th>Major Paper</th>
            <th>Total</th>
            <th>Average</th>
         </tr>
       </thead>

     </table>
<script src="<?php echo base_url('assets/jquery/jquery-2.2.3.min.js')?>"></script>
<script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>


     <!-- Script -->
     <script type="text/javascript">
     $(document).ready(function(){
        //$('#studentTable').destroy();
        $('#studentTable').DataTable({
          'processing': true,
          'serverSide': true,
          'serverMethod': 'post',
          'ajax': {
             'url':'<?php echo base_url('ajax_list'); ?>'
          },
          'columns': [
             { data: 'name' },
             { data: 'email' },
             { data: 'department' },
             { data: 'registration_id' },
             { data: 'course_joined' },
             { data: 'tamil' },
             { data: 'english' },
             { data: 'maths' },
             { data: 'elective1' },
             { data: 'elective2' },
             { data: 'major' },
             { data: 'total' },
             { data: 'avg' },
          ]
        });
     });
     </script>
  </body>
</html>