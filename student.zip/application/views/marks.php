<br>
<div class="section-title">Student Marks</div>
<form method="post" action="">
<div class="row">
	<div class="col-lg-6">
		<div class="form-group">
			<label>Student Name</label>
			<?= form_input(['name' => 'name', 'value' => set_value('name'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('name')?></div>
		</div>


		<div class="form-group">
			<label>Email</label>
			<?= form_input(['name' => 'email', 'value' => set_value('email'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('email')?></div>
		</div>

		<div class="form-group">
			<label>Photo</label>
			<?= form_upload(['name'=>'userfile', 'class'=>'form-control', 'value' => ''])?>
             <div class="text-secondary">* Upload PNG, JPG format. Image should not be more than 400KB</div>
            <div class="text-danger">
	            <?php 
		            if (isset($upload_errors))
		            {
		            	print $upload_errors;
		            }
		            else
		            {
		            	print form_error('userfile');
		            }  
	            ?>	
            </div>
		</div>

		<div class="form-group">
			<label>Address</label>
			<?= form_textarea(['name' => 'address', 'value' => set_value('address'), 'class'=>'form-control', 'rows'=>'5'])?>
			<div class="text-danger"><?= form_error('address')?></div>
		</div>

		<div class="form-group">
			<label>Student ID</label>
			<?= form_input(['name' => 'student_id', 'value' => set_value('student_id'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('student_id')?></div>
		</div>
	</div>
	<div class="col-lg-6">
		<div class="form-group">
			<label>Department</label>
			<?php 
				$options = array(
					"" 	=> "Select Department",
					"1"	=> "Science",
					"2"	=> "Commerce",
					"3"	=> "Arts",
				);
			 ?>
			 <?= form_dropdown('department', $options, set_value('department'), array('class'=>'form-control'))?>
			<div class="text-danger"><?= form_error('department')?></div>
		</div>

		<div class="form-group">
			<label>Course Joined</label>
			<input type="date" class="form-control" name="course_joined" value="<?php set_value('course_joined'); ?>">
			<div class="text-danger"><?= form_error('course_joined')?></div>
		</div>
		
	
		<div class="form-group">
			<?= form_submit(['name'=> 'submit', 'value'=> 'Add Student', 'class'=>'btn btn-primary'])?>
		</div>
		
	</div>
	
</div>

</form>
<br>
