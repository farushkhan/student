<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

     <!--=== CSS ===-->

    <!-- Bootstrap css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <!-- Font-awesome css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/all.css'); ?>">

    <!-- My css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/style.css'); ?>">


    <title>Student | Home</title>

</head>

<body>
	<div class="container">
<div class="section-title">Student Details</div>
<form method="post" action="" enctype="multipart/form-data">
<div class="row">
	<div class="col-lg-6">
		<div class="form-group">
			<label>Student Name</label>
			<?= form_input(['name' => 'name', 'value' => set_value('name'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('name')?></div>
		</div>


		<div class="form-group">
			<label>Email</label>
			<?= form_input(['name' => 'email', 'value' => set_value('email'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('email')?></div>
		</div>

		<div class="form-group">
			<label>Photo</label>
			<?= form_upload(['name'=>'userfile', 'class'=>'form-control', 'value' => ''])?>
             <div class="text-secondary">* Upload PNG, JPG format. Image should not be more than 400KB</div>
            <div class="text-danger">
	            <?php 
		            if (isset($upload_errors))
		            {
		            	print $upload_errors;
		            }
		            else
		            {
		            	print form_error('userfile');
		            }  
	            ?>	
            </div>
		</div>

		<div class="form-group">
			<label>Address</label>
			<?= form_textarea(['name' => 'address', 'value' => set_value('address'), 'class'=>'form-control', 'rows'=>'5'])?>
			<div class="text-danger"><?= form_error('address')?></div>
		</div>

		<div class="form-group">
			<label>Student ID</label>
			<?= form_input(['name' => 'registration_id', 'value' => set_value('registration_id'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('registration_id')?></div>
		</div>
	</div>
	<div class="col-lg-6">
		<div class="form-group">
			<label>Department</label>
			<?php 
				$options = array(
					"" 	=> "Select Department",
					"Science"	=> "Science",
					"Commerce"	=> "Commerce",
					"Arts"	=> "Arts",
				);
			 ?>
			 <?= form_dropdown('department', $options, set_value('department'), array('class'=>'form-control'))?>
			<div class="text-danger"><?= form_error('department')?></div>
		</div>

		<div class="form-group">
			<label>Course Joined</label>
			<input type="date" class="form-control" name="course_joined" value="<?php set_value('course_joined'); ?>">
			<div class="text-danger"><?= form_error('course_joined')?></div>
		</div>
		
	
		<div class="form-group">
			<?= form_submit(['name'=> 'submit', 'value'=> 'Add Student', 'class'=>'btn btn-primary'])?>
		</div>
		
	</div>
	
</div>
</div>
</form>
</body>
</html>

