<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

     <!--=== CSS ===-->

    <!-- Bootstrap css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <!-- Font-awesome css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/all.css'); ?>">

    <!-- My css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/style.css'); ?>">


    <title>Student | Details</title>

</head>

<body>
  <div class="container">
<br>
<div class="section-title">Add Student Marks</div>
<form method="post" action="" >
<div class="row">
	<div class="col-lg-6">
		<div class="form-group">
			<label>Tamil</label>
			<?= form_input(['name' => 'tamil', 'value' => set_value('tamil'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('tamil')?></div>
		</div>

		<div class="form-group">
			<label>English</label>
			<?= form_input(['name' => 'english', 'value' => set_value('english'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('english')?></div>
		</div>

		<div class="form-group">
			<label>Maths</label>
			<?= form_input(['name' => 'maths', 'value' => set_value('maths'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('maths')?></div>
		</div>

		<div class="form-group">
			<label>Elective1</label>
			<?= form_input(['name' => 'elective1', 'value' => set_value('elective1'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('elective1')?></div>
		</div>

		<div class="form-group">
			<label>Elective2</label>
			<?= form_input(['name' => 'elective2', 'value' => set_value('elective2'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('elective2')?></div>
		</div>

		<div class="form-group">
			<label>Major Paper</label>
			<?= form_input(['name' => 'major', 'value' => set_value('major'), 'class'=>'form-control'])?>
			<div class="text-danger"><?= form_error('major')?></div>
		</div>
		
		<div class="form-group">
			<?= form_submit(['name'=> 'submit', 'value'=> 'Add Student', 'class'=>'btn btn-primary'])?>
		</div>
		
	</div>
	
</div>

</form>
<br>
</div>
</body>
</html>
