<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

     <!--=== CSS ===-->

    <!-- Bootstrap css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <!-- Font-awesome css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/all.css'); ?>">

    <!-- My css -->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/style.css'); ?>">


    <title>Student | Details</title>

</head>

<body>
  <div class="container">
<br>
<!--=== Success msg ===-->
<?php 
    if($this->session->flashdata('success'))
    {
        print '<div class= "success-msg">'.$this->session->flashdata('success').'</div>';
    }
?>
	<div class="section-title">All Students list</div>
  <a class="btn btn-primary" style="float: right;" href="<?= base_url('students_details'); ?>">Go to Mark Details</a>
  <br>
	<table class="table table-responsive-lg">
  <thead class="thead-light">
    <tr>
    </tr>
  </thead>


  <tbody>
  	<?php foreach($students as $student): ?>
    <tr>
      <td><?php print '<img src="'.strip_tags($student->profile_image).'" width="120" height = "120">'; ?></td>
      <td>
        <p><b>ID:</b> <?= strip_tags($student->id)?></p>

        <h6><b>Student Name:</b> <a href = "<?= base_url('users/student_details/'.$student->id.'')?>" class="text-info"><?= strip_tags($student->name)?></a></h6>

        <p><b>Student ID:</b> <?= strip_tags($student->registration_id)?></p>
        
        <p><b>Email:</b> <?= strip_tags($student->email)?></p>
      </td>
      <td>
        <div class="action-btn">
          <a href="<?= base_url('add_marks/'.$student->id.'')?>" class="text-primary">Add marks</a><br>
        </div>
      </td>
    </tr>
	<?php endforeach; ?>
  </tbody>
</table>
</div>
</div>
</body>
</html>
